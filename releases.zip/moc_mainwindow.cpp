/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.0.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../INTELLIpad/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.0.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[54];
    char stringdata0[676];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(35, 0), // ""
QT_MOC_LITERAL(36, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(60, 26), // "on_actionSave_As_triggered"
QT_MOC_LITERAL(87, 34), // "on_actionSave_and_Quit_2_trig..."
QT_MOC_LITERAL(122, 31), // "on_actionPrint_to_PDF_triggered"
QT_MOC_LITERAL(154, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(177, 23), // "on_actionQuit_triggered"
QT_MOC_LITERAL(201, 23), // "on_actionCopy_triggered"
QT_MOC_LITERAL(225, 24), // "on_actionPaste_triggered"
QT_MOC_LITERAL(250, 22), // "on_actionCut_triggered"
QT_MOC_LITERAL(273, 23), // "on_actionUndo_triggered"
QT_MOC_LITERAL(297, 23), // "on_actionRedo_triggered"
QT_MOC_LITERAL(321, 23), // "on_textEdit_textChanged"
QT_MOC_LITERAL(345, 27), // "on_listWidget_itemActivated"
QT_MOC_LITERAL(373, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(390, 4), // "item"
QT_MOC_LITERAL(395, 32), // "on_actionLower_Element_triggered"
QT_MOC_LITERAL(428, 32), // "on_actionUpper_Element_triggered"
QT_MOC_LITERAL(461, 21), // "addSelectedItemToText"
QT_MOC_LITERAL(483, 33), // "on_actionSelect_Element_trigg..."
QT_MOC_LITERAL(517, 40), // "on_actionAdd_all_to_Dictionar..."
QT_MOC_LITERAL(558, 23), // "on_actionBold_triggered"
QT_MOC_LITERAL(582, 26), // "on_actionItalics_triggered"
QT_MOC_LITERAL(609, 29), // "on_actionUnderlined_triggered"
QT_MOC_LITERAL(639, 36) // "on_actionSelect_Dictionary_tr..."

    },
    "MainWindow\0on_actionOpen_triggered\0\0"
    "on_actionSave_triggered\0"
    "on_actionSave_As_triggered\0"
    "on_actionSave_and_Quit_2_triggered\0"
    "on_actionPrint_to_PDF_triggered\0"
    "on_actionNew_triggered\0on_actionQuit_triggered\0"
    "on_actionCopy_triggered\0"
    "on_actionPaste_triggered\0"
    "on_actionCut_triggered\0on_actionUndo_triggered\0"
    "on_actionRedo_triggered\0on_textEdit_textChanged\0"
    "on_listWidget_itemActivated\0"
    "QListWidgetItem*\0item\0"
    "on_actionLower_Element_triggered\0"
    "on_actionUpper_Element_triggered\0"
    "addSelectedItemToText\0"
    "on_actionSelect_Element_triggered\0"
    "on_actionAdd_all_to_Dictionary_triggered\0"
    "on_actionBold_triggered\0"
    "on_actionItalics_triggered\0"
    "on_actionUnderlined_triggered\0"
    "on_actionSelect_Dictionary_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       9,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  152,    2, 0x08,    0 /* Private */,
       3,    0,  153,    2, 0x08,    1 /* Private */,
       4,    0,  154,    2, 0x08,    2 /* Private */,
       5,    0,  155,    2, 0x08,    3 /* Private */,
       6,    0,  156,    2, 0x08,    4 /* Private */,
       7,    0,  157,    2, 0x08,    5 /* Private */,
       8,    0,  158,    2, 0x08,    6 /* Private */,
       9,    0,  159,    2, 0x08,    7 /* Private */,
      10,    0,  160,    2, 0x08,    8 /* Private */,
      11,    0,  161,    2, 0x08,    9 /* Private */,
      12,    0,  162,    2, 0x08,   10 /* Private */,
      13,    0,  163,    2, 0x08,   11 /* Private */,
      14,    0,  164,    2, 0x08,   12 /* Private */,
      15,    1,  165,    2, 0x08,   13 /* Private */,
      18,    0,  168,    2, 0x08,   15 /* Private */,
      19,    0,  169,    2, 0x08,   16 /* Private */,
      20,    0,  170,    2, 0x08,   17 /* Private */,
      21,    0,  171,    2, 0x08,   18 /* Private */,
      22,    0,  172,    2, 0x08,   19 /* Private */,
      23,    0,  173,    2, 0x08,   20 /* Private */,
      24,    0,  174,    2, 0x08,   21 /* Private */,
      25,    0,  175,    2, 0x08,   22 /* Private */,
      26,    0,  176,    2, 0x08,   23 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_actionOpen_triggered(); break;
        case 1: _t->on_actionSave_triggered(); break;
        case 2: _t->on_actionSave_As_triggered(); break;
        case 3: _t->on_actionSave_and_Quit_2_triggered(); break;
        case 4: _t->on_actionPrint_to_PDF_triggered(); break;
        case 5: _t->on_actionNew_triggered(); break;
        case 6: _t->on_actionQuit_triggered(); break;
        case 7: _t->on_actionCopy_triggered(); break;
        case 8: _t->on_actionPaste_triggered(); break;
        case 9: _t->on_actionCut_triggered(); break;
        case 10: _t->on_actionUndo_triggered(); break;
        case 11: _t->on_actionRedo_triggered(); break;
        case 12: _t->on_textEdit_textChanged(); break;
        case 13: _t->on_listWidget_itemActivated((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 14: _t->on_actionLower_Element_triggered(); break;
        case 15: _t->on_actionUpper_Element_triggered(); break;
        case 16: _t->addSelectedItemToText(); break;
        case 17: _t->on_actionSelect_Element_triggered(); break;
        case 18: _t->on_actionAdd_all_to_Dictionary_triggered(); break;
        case 19: _t->on_actionBold_triggered(); break;
        case 20: _t->on_actionItalics_triggered(); break;
        case 21: _t->on_actionUnderlined_triggered(); break;
        case 22: _t->on_actionSelect_Dictionary_triggered(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t

, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 23;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
